<?php
$hostname = "localhost";
$username = "root";
$password = "";  
$database = "website_project";   
$con=mysqli_connect($hostname,$username,$password,$database);    
?>   